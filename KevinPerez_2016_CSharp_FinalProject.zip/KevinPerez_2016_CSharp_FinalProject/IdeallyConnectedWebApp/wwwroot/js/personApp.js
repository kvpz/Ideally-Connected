﻿// the angular.module function is used to create a new instance of the module that we will be working with.
(function () {
    'use strict';
    var app = angular.module('PersonApp', []);
})();