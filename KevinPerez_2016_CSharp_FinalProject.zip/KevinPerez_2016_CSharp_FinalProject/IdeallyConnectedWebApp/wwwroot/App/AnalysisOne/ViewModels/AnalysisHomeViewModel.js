﻿analysisModule.controller("analysisHomeViewModel", function ($scope, analysisService, viewModelHelper) {

        $scope.viewModelHelper = viewModelHelper;
        $scope.analysisService = analysisService;

        var initialize = function () { }

        initialize();
    });
