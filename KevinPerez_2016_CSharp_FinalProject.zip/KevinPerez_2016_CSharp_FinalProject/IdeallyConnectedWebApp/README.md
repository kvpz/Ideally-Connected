﻿
For setting up angularjs:
https://docs.asp.net/en/latest/client-side/angular.html
